# meminta pengguna untuk memasukkan suhu dalam Celcius
celsius = float(input("Input suhu dalam Celcius: "))

# menghitung suhu dalam Reamur, Fahrenheit, dan Kelvin menggunakan rumus yang diberikan
reamur = celsius * 4/5
fahrenheit = (celsius * 9/5) + 32
kelvin = celsius + 273

# mencetak hasil konversi suhu dalam Reamur, Fahrenheit, dan Kelvin
print(f"Besaran suhu dalam Reamur: {reamur:.1f} R")
print(f"Besaran suhu dalam Fahrenheit: {fahrenheit:.1f} F")
print(f"Besaran suhu dalam Kelvin: {kelvin:.1f} K")
