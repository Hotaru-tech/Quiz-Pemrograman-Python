# Input jumlah bilangan genap
jumlah_genap = int(input("Masukkan jumlah bilangan genap: "))

# Menampilkan bilangan genap
for i in range(1, jumlah_genap+1):
    print(i*2, end=" ")

print()

# Input jumlah bilangan ganjil
jumlah_ganjil = int(input("Masukkan jumlah bilangan ganjil: "))

# Menampilkan bilangan ganjil
for i in range(jumlah_ganjil):
    print(i*2+1, end=" ")
