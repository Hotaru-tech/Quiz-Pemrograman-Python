# meminta pengguna untuk memasukkan data diri
nama = input("Nama: ")
umur = input("Umur: ")
kota_lahir = input("Kota Lahir: ")

# menampilkan menu dengan 2 opsi
print("Tampilan Menu:")
print("1. Munculkan Data Diri")
print("2. Keluar Dari Aplikasi")

# meminta pengguna untuk memilih opsi
pilihan = input("Pilih: ")

# menggunakan kondisi if-else untuk mengecek pilihan pengguna
if pilihan == "1":
    print(f"Nama: {nama}")
    print(f"Umur: {umur}")
    print(f"Kota Lahir: {kota_lahir}")
elif pilihan == "2":
    print("Anda telah keluar dari aplikasi.")
else:
    print("Pilihan yang Anda masukkan tidak valid.")
