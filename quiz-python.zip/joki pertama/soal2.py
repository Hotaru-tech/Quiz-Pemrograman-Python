print("Tampilan Menu:")
print("1. Nilai PMP")
print("2. Nilai PPMP")

pilihan = int(input("Pilih: "))

if pilihan == 1:
    nilai = int(input("Nilai PMP: "))
    if nilai >= 90:
        print("Kamu mendapat nilai: A")
    elif nilai >= 80:
        print("Kamu mendapat nilai: B")
    elif nilai >= 70:
        print("Kamu mendapat nilai: C")
    elif nilai >= 60:
        print("Kamu mendapat nilai: D")
    else:
        print("Kamu mendapat nilai: E")
elif pilihan == 2:
    nilai = int(input("Nilai PPMP: "))
    if nilai >= 90:
        print("Kamu mendapat nilai: A")
    elif nilai >= 80:
        print("Kamu mendapat nilai: B")
    elif nilai >= 70:
        print("Kamu mendapat nilai: C")
    elif nilai >= 60:
        print("Kamu mendapat nilai: D")
    else:
        print("Kamu mendapat nilai: E")
else:
    print("Pilihan tidak valid.")
