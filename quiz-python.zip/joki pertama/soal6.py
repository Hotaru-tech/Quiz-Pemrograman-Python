nim = input("Masukkan NIM: ")
nama = input("Masukkan Nama: ")
kelas = input("Masukkan Kelas: ")

# daftar matakuliah dan jumlah SKS
matakuliah = {
    "UNP 01": "Pemrograman Website",
    "UNP 02": "Pemrograman Multi Platform",
    "UNP 03": "Praktek Pemrograman Multi Platform"
}
sks = {
    "UNP 01": 4,
    "UNP 02": 4,
    "UNP 03": 2
}

# tampilkan detail KRS
print("Detail KRS:")
print("Kode MK  Nama MK                               SKS")
total_sks = 0
for kode, nama in matakuliah.items():
    sks_mk = sks[kode]
    total_sks += sks_mk
    print(f"{kode}  {nama.ljust(35)}  {sks_mk}")

print(f"Total SKS yang Diambil = {total_sks}")
