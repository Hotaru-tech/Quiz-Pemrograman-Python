nama = input("Nama Mahasiswa: ")
umur = input("Umur: ")
pmp = float(input("Nilai Pemrograman Multi Platform: "))
ppmp = float(input("Nilai Praktek Pemrograman Multi Platform: "))

total = pmp + ppmp
rerata = total / 2

print("Nilai Total: ", total)
print("Nilai Rata-Rata: ", rerata)
